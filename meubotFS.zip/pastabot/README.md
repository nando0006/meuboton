# Termux Bot Whatsapp V2 by MrDevils

<p align="center">
<img src="https://d.top4top.io/p_1837luigd0.gif" alt="GIF" width="128" height="128"/>
</p>
<p align="center">
<a href="#"><img title="X BOT" src="https://img.shields.io/badge/XBotV2-blue?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/adimas999"><img title="Author" src="https://img.shields.io/badge/Author-MrDevils-orange.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://github.com/adimas999/followers"><img title="Followers" src="https://img.shields.io/github/followers/adimas999?color=red&style=flat-square"></a>
<a href="https://github.com/adimas999/megumikato2/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/adimas999/BotV2?color=blue&style=flat-square"></a>
<a href="https://github.com/adimas999/megumikato2/network/members"><img title="Forks" src="https://img.shields.io/github/forks/adimas999/BotV2?color=red&style=flat-square"></a>
<a href="https://github.com/adimas999/megumikato2/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/adimas999/BotV2?label=Watchers&color=blue&style=flat-square"></a>
</p>
<p align='center'>
   <a href="https://wa.me/6285939888897"><img height="30" src="https://c.top4top.io/p_1837yybbf0.jpeg"></a>&nbsp;&nbsp;
   <a href="https://instagram.com/adimas_shadoet"><img height="30" src="https://raw.githubusercontent.com/TobyG74/TobyG74/main/instagram.jpg"></a>
</P>
</P>

## Information

#### This script is open to anyone! If you want to add commands, please contribute / pull request! Buying and selling scripts is prohibited!
- Change [ownerNumber](https://github.com/adimas999/BotV2/blob/b304c9ebb31efff1fa91570ff3386cb42c47f9d2/index.js#L221) in index.js to be your number
ownerNumber = "6282334297175@s.whatsapp.net"
- Change [BotInfo](https://github.com/adimas999/BotV2/blob/fbd8e4ae0a3b51dd6eecac7bd225ff8ed2650316/index.js#L29) in index.js to be your bot name
- Change [Donasi](https://github.com/adimas999/BotV2/blob/main/lib/donasi.js) in /lib/donasi.js to be your number

## Contact

If you find some bugs please contact the WhatsApp number on Contact

- [WHATSAPP](https://wa.me/6285939888897)

### Install
Clone this project

```bash
> pkg install git
> git clone https://github.com/adimas999/BotV2
> cd BotV2-main
```

Install the dependencies:

```bash
> pkg install bash
> bash install.sh
```

### Usage
run the Whatsapp bot

```bash
> node index.js
```
after running it you need to scan the qr

## 🙏 Big Special Thanks To

* [`MrDevil`](https://github.com/adimas999) 
* [`Mhankbarbar`](https://github.com/MhankBarBar) 
